import os
from PyQt6.QtWidgets import (
    QMainWindow, QMessageBox, QWidget, QVBoxLayout,
    QDialog, QTableWidgetItem, QHeaderView, QFileDialog
)
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtGui import QPixmap
from PyQt6.uic import loadUi


def get_ui_path(filename):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(current_dir, 'ui', filename)


class AdminWindow(QMainWindow):
    def __init__(self, user, db):
        super().__init__()
        self.user = user
        self.db = db

        loadUi(get_ui_path('list_product.ui'), self)

        self.fio_label.setText(f"{user['fio']} (Администратор)")
        self.btn_exit.clicked.connect(self.exit_to_auth)

        self.btn_analis.setVisible(True)
        self.btn_to_add_item.setVisible(True)
        self.btn_orders.setVisible(True)

        self.load_manufacturers()
        self.load_suppliers()

        self.finder_line.textChanged.connect(self.load_products)
        self.comboBox_manufacturer.currentIndexChanged.connect(self.load_products)
        self.comboBox_supplier.currentIndexChanged.connect(self.load_products)
        self.btn_to_add_item.clicked.connect(self.add_product)
        self.btn_analis.clicked.connect(self.show_analytics)
        self.btn_orders.clicked.connect(self.show_orders)

        self.load_products()

    def exit_to_auth(self):
        from auth import AuthWindow
        self.auth_window = AuthWindow()
        self.auth_window.show()
        self.close()

    def load_manufacturers(self):
        self.comboBox_manufacturer.clear()
        self.comboBox_manufacturer.addItem("Все производители", None)
        for m in self.db.get_manufacturers():
            self.comboBox_manufacturer.addItem(m['name'], m['id'])

    def load_suppliers(self):
        self.comboBox_supplier.clear()
        self.comboBox_supplier.addItem("Все поставщики", None)
        for s in self.db.get_suppliers():
            self.comboBox_supplier.addItem(s['name'], s['id'])

    def load_products(self):
        products = self.db.get_products(
            self.finder_line.text().strip(),
            self.comboBox_manufacturer.currentData(),
            self.comboBox_supplier.currentData()
        )

        if self.scrollArea.widget():
            self.scrollArea.widget().deleteLater()

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        for p in products:
            layout.addWidget(self._create_card(p))
        layout.addStretch()
        self.scrollArea.setWidget(container)

    def _create_card(self, p):
        card = QWidget()
        loadUi(get_ui_path('product_card.ui'), card)

        card.name_label.setText(p['name'])
        card.category_label.setText(p.get('category_name', 'Без категории'))
        card.description_label.setText(f"Описание: {(p.get('description') or 'Отсутствует')[:100]}...")
        card.manufacturer_label.setText(f"Производитель: {p.get('manufacturer_name', 'не указан')}")
        card.supplier_label.setText(f"Поставщики: {p.get('suppliers_list', 'не указаны')}")
        card.count_label.setText(f"В наличии: {p['stock']} шт.")
        card.price_label.setText(f"{p['price']:.2f} руб.")

        if img := p.get('image'):
            full = os.path.join(os.path.dirname(os.path.abspath(__file__)), img)
            if os.path.exists(full) and (pix := QPixmap(full)) and not pix.isNull():
                card.image.setPixmap(pix.scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio))
                card.image.setText("")
        else:
            card.image.setText("Нет фото")

        card.btn_edit.clicked.connect(lambda _, x=p: self.edit_product(x))
        card.btn_delete.clicked.connect(lambda _, x=p['id']: self.delete_product(x))
        card.btn_add_to_basket.hide()

        return card

    def add_product(self):
        if ProductEditDialog(self.db).exec():
            self.load_products()

    def edit_product(self, product):
        if ProductEditDialog(self.db, product).exec():
            self.load_products()

    def delete_product(self, product_id):
        if QMessageBox.question(self, "Подтверждение", "Удалить товар?",
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            self.db.delete_product(product_id)
            self.load_products()
            QMessageBox.information(self, "Успех", "Товар удален")

    def show_analytics(self):
        AnalyticsDialog(self.db).exec()

    def show_orders(self):
        OrdersManageDialog(self.db, self.user).exec()
        self.load_products()


class ProductEditDialog(QDialog):
    def __init__(self, db, product=None):
        super().__init__()
        self.db = db
        self.product = product
        self.image_path = product['image'] if product else None

        loadUi(get_ui_path('form_add_edit_product.ui'), self)
        self.setWindowTitle("Редактирование" if product else "Добавление")

        self._load_combos()
        if product:
            self._fill_data(product)

        self.btn_to_add_photo.clicked.connect(self._select_image)
        self.btn_save.clicked.connect(self._save)

    def _load_combos(self):
        for cat in self.db.get_categories():
            self.comboBox_category.addItem(cat['name'], cat['id'])
        for m in self.db.get_manufacturers():
            self.combo_manufacturer.addItem(m['name'], m['id'])
        for s in self.db.get_suppliers():
            self.comboBox_supplier.addItem(s['name'], s['id'])

    def _fill_data(self, p):
        self.id_line.setText(str(p['id']))
        self.name_line.setText(p['name'])
        self.description_label_2.setText(p['description'] or '')
        self.doubleSpinBox_price.setValue(float(p['price']))
        self.spinBox_count.setValue(p['stock'])

        if (idx := self.comboBox_category.findData(p['category_id'])) >= 0:
            self.comboBox_category.setCurrentIndex(idx)
        if (idx := self.combo_manufacturer.findData(p['manufacturer_id'])) >= 0:
            self.combo_manufacturer.setCurrentIndex(idx)

        if supps := self.db.get_product_suppliers(p['id']):
            if (idx := self.comboBox_supplier.findData(supps[0])) >= 0:
                self.comboBox_supplier.setCurrentIndex(idx)

        if p['image'] and os.path.exists(p['image']):
            self.label.setPixmap(QPixmap(p['image']).scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio))

    def _select_image(self):
        if path := QFileDialog.getOpenFileName(self, "Выбрать изображение", "", "*.png *.jpg *.jpeg")[0]:
            self.image_path = path
            self.label.setPixmap(QPixmap(path).scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio))

    def _save(self):
        if not (name := self.name_line.text().strip()):
            return QMessageBox.warning(self, "Ошибка", "Введите название")

        args = [name, self.description_label_2.text().strip(),
                self.comboBox_category.currentData(), self.combo_manufacturer.currentData(),
                self.doubleSpinBox_price.value(), self.spinBox_count.value(),
                self.image_path, [self.comboBox_supplier.currentData()] if self.comboBox_supplier.currentData() else []]

        try:
            if self.product:
                self.db.update_product(self.product['id'], *args)
            else:
                self.db.add_product(*args)
            QMessageBox.information(self, "Успех", "Сохранено")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))


class AnalyticsDialog(QDialog):
    def __init__(self, db):
        super().__init__()
        self.db = db
        loadUi(get_ui_path('analytics.ui'), self)
        self.btn_close.clicked.connect(self.accept)
        self._load_data()

    def _load_data(self):
        total = self.db.get_total_sales()
        self.total_label.setText(f"Общая сумма продаж (завершенных): {total:,.2f} руб.")

        statuses = self.db.get_orders_by_status()
        self.status_table.setRowCount(len(statuses))
        for i, s in enumerate(statuses):
            self.status_table.setItem(i, 0, QTableWidgetItem(s['status']))
            self.status_table.setItem(i, 1, QTableWidgetItem(str(s['count'] or 0)))
            self.status_table.setItem(i, 2, QTableWidgetItem(f"{s['sum'] or 0:,.2f} руб."))

        popular = self.db.get_popular_products(10)
        self.popular_table.setRowCount(len(popular))
        for i, p in enumerate(popular):
            self.popular_table.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            self.popular_table.setItem(i, 1, QTableWidgetItem(p['name']))
            self.popular_table.setItem(i, 2, QTableWidgetItem(str(p['sold'] or 0)))
            self.popular_table.setItem(i, 3, QTableWidgetItem(f"{p['revenue'] or 0:,.2f} руб."))


class OrdersManageDialog(QDialog):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user

        loadUi(get_ui_path('orders.ui'), self)
        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        self._load_filters()
        self.lineEdit_poisk.textChanged.connect(self._load)
        self.dateEdit.dateChanged.connect(self._load)
        self.comboBox_clients.currentIndexChanged.connect(self._load)
        self.comboBox_status.currentIndexChanged.connect(self._load)
        self.btn_cnange_button.clicked.connect(self._change_status)
        self._load()

    def _load_filters(self):
        for c in self.db.get_all_clients():
            self.comboBox_clients.addItem(c['fio'], c['id'])
        for s in self.db.get_order_statuses():
            self.comboBox_status.addItem(s['name'], s['id'])

    def _load(self):
        orders = self.db.get_orders(
            self.lineEdit_poisk.text().strip(),
            self.dateEdit.date().toString("yyyy-MM-dd"),
            self.comboBox_clients.currentData(),
            self.comboBox_status.currentData()
        )
        self.tableWidget.setRowCount(len(orders))
        for i, o in enumerate(orders):
            self.tableWidget.setItem(i, 0, QTableWidgetItem(str(o['id'])))
            self.tableWidget.setItem(i, 1, QTableWidgetItem(o['client_name']))
            self.tableWidget.setItem(i, 2, QTableWidgetItem(str(o['order_date'])))
            self.tableWidget.setItem(i, 3, QTableWidgetItem(o['status_name']))
            self.tableWidget.setItem(i, 4, QTableWidgetItem(f"{o['total_price']:,.2f}"))
            self.tableWidget.setItem(i, 5, QTableWidgetItem(o['delivery_method']))
            self.tableWidget.setItem(i, 6, QTableWidgetItem(o['address']))
            self.tableWidget.setItem(i, 7, QTableWidgetItem(o['payment_method']))

    def _change_status(self):
        row = self.tableWidget.currentRow()
        if row < 0:
            return QMessageBox.warning(self, "Ошибка", "Выберите заказ")

        order_id = int(self.tableWidget.item(row, 0).text())
        dialog = ChangeStatusDialog(self.db, order_id, self)
        if dialog.exec():
            self._load()


class ChangeStatusDialog(QDialog):
    def __init__(self, db, order_id, parent=None):
        super().__init__(parent)
        self.db = db
        self.order_id = order_id

        loadUi(get_ui_path('change_status_dialog.ui'), self)

        for s in self.db.get_order_statuses():
            self.combo_status.addItem(s['name'], s['id'])

        self.btn_save.clicked.connect(self._save)
        self.btn_cancel.clicked.connect(self.reject)

    def _save(self):
        self.db.update_order_status(self.order_id, self.combo_status.currentData())
        QMessageBox.information(self, "Успех", "Статус обновлен")
        self.accept()