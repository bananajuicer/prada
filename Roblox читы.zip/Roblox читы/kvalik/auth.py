import os
from PyQt6.QtWidgets import QMainWindow, QMessageBox
from PyQt6.uic import loadUi
from db import Database
from admin import AdminWindow
from manager import ManagerWindow
from client import ClientWindow
from guest import GuestWindow

def get_ui_path(filename):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(current_dir, 'ui', filename)

class AuthWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db = Database()

        ui_path = get_ui_path('auth.ui')
        loadUi(ui_path, self)

        self.btn_login.clicked.connect(self.login)
        self.btn_guest.clicked.connect(self.guest_mode)

    def login(self):
        login = self.line_login.text().strip()
        password = self.line_password.text().strip()

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль")
            return

        user = self.db.get_user(login, password)
        if user:
            self.open_window_by_role(user)
        else:
            QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль")

    def guest_mode(self):
        guest_user = {'id': None, 'fio': 'Гость', 'role_name': 'guest'}
        self.guest_window = GuestWindow(guest_user, self.db)
        self.guest_window.show()
        self.close()

    def open_window_by_role(self, user):
        role = user['role_name']

        if role == 'admin':
            self.window = AdminWindow(user, self.db)
        elif role == 'manager':
            self.window = ManagerWindow(user, self.db)
        elif role == 'client':
            self.window = ClientWindow(user, self.db)
        else:
            self.window = GuestWindow(user, self.db)

        self.window.show()
        self.close()