import os
from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.uic import loadUi


def get_ui_path(filename):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(current_dir, 'ui', filename)


class ManagerWindow(QMainWindow):
    def __init__(self, user, db):
        super().__init__()
        self.user = user
        self.db = db

        ui_path = get_ui_path('list_product.ui')
        loadUi(ui_path, self)

        self.fio_label.setText(f"{user['fio']} (Менеджер)")
        self.btn_exit.clicked.connect(self.exit_to_auth)

        self.btn_analis.setVisible(True)
        self.btn_to_add_item.setVisible(False)
        self.btn_orders.setVisible(True)

        self.load_manufacturers()
        self.load_suppliers()

        self.finder_line.textChanged.connect(self.load_products)
        self.comboBox_manufacturer.currentIndexChanged.connect(self.load_products)
        self.comboBox_supplier.currentIndexChanged.connect(self.load_products)
        self.btn_analis.clicked.connect(self.show_analytics)
        self.btn_orders.clicked.connect(self.show_orders)

        self.load_products()

    def load_manufacturers(self):
        manufacturers = self.db.get_manufacturers()
        self.comboBox_manufacturer.clear()
        self.comboBox_manufacturer.addItem("Все производители", None)
        for m in manufacturers:
            self.comboBox_manufacturer.addItem(m['name'], m['id'])

    def load_suppliers(self):
        suppliers = self.db.get_suppliers()
        self.comboBox_supplier.clear()
        self.comboBox_supplier.addItem("Все поставщики", None)
        for s in suppliers:
            self.comboBox_supplier.addItem(s['name'], s['id'])

    def load_products(self):
        search = self.finder_line.text().strip()
        manufacturer_id = self.comboBox_manufacturer.currentData()
        supplier_id = self.comboBox_supplier.currentData()

        products = self.db.get_products(search, manufacturer_id, supplier_id)

        if self.scrollArea.widget():
            self.scrollArea.widget().deleteLater()

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        for product in products:
            card = self.create_product_card(product)
            layout.addWidget(card)

        layout.addStretch()
        self.scrollArea.setWidget(container)

    def load_products(self):
        # Получаем все товары без поиска и фильтров
        products = self.db.get_products()

        if self.scrollArea.widget():
            self.scrollArea.widget().deleteLater()

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        for product in products:
            card = self.create_product_card(product)
            layout.addWidget(card)

        layout.addStretch()
        self.scrollArea.setWidget(container)

    def create_product_card(self, product):
        card = QWidget()
        ui_path = get_ui_path('product_card.ui')
        loadUi(ui_path, card)

        card.name_label.setText(product['name'])
        card.category_label.setText(product.get('category_name') or 'Без категории')
        card.description_label.setText(f"Описание: {(product.get('description') or 'Отсутствует')[:100]}...")
        card.manufacturer_label.setText(f"Производитель: {product.get('manufacturer_name', 'не указан')}")
        card.supplier_label.setText(f"Поставщики: {product.get('suppliers_list', 'не указаны')}")
        card.count_label.setText(f"В наличии: {product['stock']} шт.")
        card.price_label.setText(f"{product['price']:.2f} руб.")

        # Картинка
        card.image.setText("Нет фото")
        if img := product.get('image'):
            full_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), img)
            if os.path.exists(full_path) and (pix := QPixmap(full_path)) and not pix.isNull():
                card.image.setPixmap(pix.scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio))
                card.image.setText("")

        # Скрываем все кнопки
        card.btn_edit.hide()
        card.btn_delete.hide()
        card.btn_add_to_basket.hide()

        return card

    def edit_product(self, product):
        from admin import ProductEditDialog
        dialog = ProductEditDialog(self.db, product)
        if dialog.exec():
            self.load_products()

    def show_analytics(self):
        from admin import AnalyticsDialog
        dialog = AnalyticsDialog(self.db)
        dialog.exec()

    def show_orders(self):
        from admin import OrdersManageDialog
        dialog = OrdersManageDialog(self.db, self.user)
        dialog.exec()
        self.load_products()

    def exit_to_auth(self):
        """Выход из системы и возврат к окну авторизации"""
        from auth import AuthWindow
        self.auth_window = AuthWindow()
        self.auth_window.show()
        self.close()