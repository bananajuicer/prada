import os
from PyQt6.QtWidgets import (
    QMainWindow, QMessageBox, QWidget, QVBoxLayout,
    QDialog, QTableWidgetItem, QHeaderView
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.uic import loadUi


def get_ui_path(filename):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ui', filename)

class BaseWindow(QMainWindow):
    def load_combo(self, combo, items, default_text="Все"):
        combo.clear()
        combo.addItem(default_text, None)
        for item in items:
            combo.addItem(item['name'], item['id'])

    def load_image(self, label, image_path):
        label.setText("Нет фото")
        if image_path and (full := os.path.join(os.path.dirname(os.path.abspath(__file__)), image_path)):
            if os.path.exists(full) and (pix := QPixmap(full)) and not pix.isNull():
                label.setPixmap(pix.scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio))
                label.setText("")

    def exit_to_auth(self):
        from auth import AuthWindow
        self.auth_window = AuthWindow()
        self.auth_window.show()
        self.close()


class ClientWindow(BaseWindow):
    def __init__(self, user, db):
        super().__init__()
        self.user = user
        self.db = db
        self.cart = []

        loadUi(get_ui_path('list_product.ui'), self)
        self._setup_ui()
        self._load_filters()
        self.load_products()

    def _setup_ui(self):
        self.fio_label.setText(f"{self.user['fio']} (Клиент)")
        self.btn_exit.clicked.connect(self.exit_to_auth)
        self.btn_analis.hide()
        self.btn_to_add_item.hide()
        self.btn_orders.show()
        self.btn_orders.clicked.connect(self.show_orders)

    def _load_filters(self):
        # Загружаем данные в комбобоксы
        self.load_combo(self.comboBox_manufacturer, self.db.get_manufacturers(), "Все производители")
        self.load_combo(self.comboBox_supplier, self.db.get_suppliers(), "Все поставщики")

        # Подключаем сигналы
        self.finder_line.textChanged.connect(self.load_products)
        self.comboBox_manufacturer.currentIndexChanged.connect(self.load_products)
        self.comboBox_supplier.currentIndexChanged.connect(self.load_products)

    def load_products(self):
        search = self.finder_line.text().strip()
        manufacturer_id = self.comboBox_manufacturer.currentData()
        supplier_id = self.comboBox_supplier.currentData()
        products = self.db.get_products(search, manufacturer_id, supplier_id)
        self._display_products(products)

    def _display_products(self, products):
        if self.scrollArea.widget():
            self.scrollArea.widget().deleteLater()

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        for p in products:
            layout.addWidget(self._create_card(p))
        layout.addStretch()
        self.scrollArea.setWidget(container)

    def _create_card(self, p):
        card = QWidget()
        loadUi(get_ui_path('product_card.ui'), card)

        texts = [
            (card.name_label, p['name']),
            (card.category_label, p.get('category_name', 'Без категории')),
            (card.description_label, f"Описание: {(p.get('description') or 'Отсутствует')[:100]}..."),
            (card.manufacturer_label, f"Производитель: {p.get('manufacturer_name', 'не указан')}"),
            (card.supplier_label, f"Поставщики: {p.get('suppliers_list', 'не указаны')}"),
            (card.count_label, f"В наличии: {p['stock']} шт."),
            (card.price_label, f"{p['price']:.2f} руб.")
        ]
        for label, text in texts:
            label.setText(text)

        self.load_image(card.image, p.get('image'))

        card.btn_edit.hide()
        card.btn_delete.hide()
        card.btn_add_to_basket.clicked.connect(lambda _, x=p: self._add_to_cart(x))

        return card

    def _add_to_cart(self, p):
        if p['stock'] <= 0:
            return QMessageBox.warning(self, "Ошибка", "Товара нет в наличии")

        for item in self.cart:
            if item['id'] == p['id']:
                if item['quantity'] < p['stock']:
                    item['quantity'] += 1
                else:
                    QMessageBox.warning(self, "Ошибка", "Недостаточно товара")
                return

        self.cart.append({'id': p['id'], 'name': p['name'], 'price': p['price'], 'quantity': 1})
        QMessageBox.information(self, "Корзина", f"Товар '{p['name']}' добавлен")

    def show_orders(self):
        dialog = ClientOrdersDialog(self.db, self.user, self.cart, self)
        dialog.exec()
        self.load_products()


class ClientOrdersDialog(QDialog):
    def __init__(self, db, user, cart, parent=None):
        super().__init__(parent)
        self.db = db
        self.user = user
        self.cart = cart

        loadUi(get_ui_path('client_orders.ui'), self)

        # Сигналы
        self.btn_create_order.clicked.connect(self._create_order)
        self.btn_clear_cart.clicked.connect(self._clear_cart)
        self.btn_refresh_history.clicked.connect(self._load_history)
        self.history_search.textChanged.connect(self._filter_history)
        self.btn_close.clicked.connect(self.accept)

        self._update_cart()
        self._load_history()

    def _update_cart(self):
        self.cart_table.setRowCount(len(self.cart))
        total = 0
        for i, item in enumerate(self.cart):
            self.cart_table.setItem(i, 0, QTableWidgetItem(item['name']))
            self.cart_table.setItem(i, 1, QTableWidgetItem(f"{item['price']:.2f}"))
            self.cart_table.setItem(i, 2, QTableWidgetItem(str(item['quantity'])))
            subtotal = item['price'] * item['quantity']
            self.cart_table.setItem(i, 3, QTableWidgetItem(f"{subtotal:.2f}"))
            total += subtotal
        self.total_label.setText(f"Итого: {total:.2f} руб.")

    def _clear_cart(self):
        self.cart.clear()
        self._update_cart()

    def _create_order(self):
        if not self.cart:
            return QMessageBox.warning(self, "Ошибка", "Корзина пуста")
        if not (addr := self.address_edit.text().strip()):
            return QMessageBox.warning(self, "Ошибка", "Введите адрес")

        try:
            oid = self.db.create_order(self.user['id'], addr, self.payment_combo.currentText(),
                                       self.delivery_combo.currentText(), self.cart)
            QMessageBox.information(self, "Успех", f"Заказ №{oid} оформлен!")
            self._clear_cart()
            self._load_history()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def _load_history(self):
        self.all_orders = self.db.get_client_orders(self.user['id'])
        self._filter_history()

    def _filter_history(self):
        if not hasattr(self, 'all_orders'):
            return

        search = self.history_search.text().strip().lower()
        filtered = [o for o in self.all_orders if
                    search in str(o['id']) or search in o['status_name'].lower()] if search else self.all_orders

        self.history_table.setRowCount(len(filtered))
        for i, o in enumerate(filtered):
            self.history_table.setItem(i, 0, QTableWidgetItem(str(o['id'])))
            self.history_table.setItem(i, 1, QTableWidgetItem(str(o['order_date'])))
            self.history_table.setItem(i, 2, QTableWidgetItem(o['status_name']))
            self.history_table.setItem(i, 3, QTableWidgetItem(f"{o['total_price']:.2f}"))
            self.history_table.setItem(i, 4, QTableWidgetItem(o['delivery_method']))
            self.history_table.setItem(i, 5, QTableWidgetItem(o['payment_method']))