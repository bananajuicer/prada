import os
from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.uic import loadUi


def get_ui_path(filename):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(current_dir, 'ui', filename)


class GuestWindow(QMainWindow):
    def __init__(self, user, db):
        super().__init__()
        self.user = user
        self.db = db

        ui_path = get_ui_path('list_product.ui')
        loadUi(ui_path, self)

        self.fio_label.setText(f"{user['fio']} (Гость)")
        self.btn_exit.clicked.connect(self.exit_to_auth)

        # Скрываем кнопки действий
        self.btn_analis.setVisible(False)
        self.btn_to_add_item.setVisible(False)
        self.btn_orders.setVisible(False)

        # Скрываем поиск и фильтры
        self.finder_line.setVisible(False)
        self.comboBox_manufacturer.setVisible(False)
        self.comboBox_supplier.setVisible(False)

        # Загружаем все товары без фильтров
        self.load_products()

    def load_products(self):
        # Получаем все товары без поиска и фильтров
        products = self.db.get_products()

        if self.scrollArea.widget(): # Очищаем старые карточки
            self.scrollArea.widget().deleteLater()

        container = QWidget() # Контейнер для карточек
        layout = QVBoxLayout(container)  # Вертикальное расположение
        layout.setSpacing(10)   # Отступ между карточками = 10px
        layout.setContentsMargins(10, 10, 10, 10)

        """МЕНЯЕТСЯ ПРИ ДРУГОЙ ПО"""
        for product in products: # Для каждого товара
            card = self.create_product_card(product) # Создаём карточку
            layout.addWidget(card) # Добавляем в layout

        layout.addStretch()  # Растягиваем пустое место вниз
        self.scrollArea.setWidget(container) # Помещаем в область прокрутки

    def create_product_card(self, product):
        card = QWidget()
        ui_path = get_ui_path('product_card.ui')
        loadUi(ui_path, card)

        # ⚠️ ЗАПОЛНЕНИЕ ПОЛЕЙ - МЕНЯТЬ ЗДЕСЬ!
        card.name_label.setText(product['name'])
        card.category_label.setText(product.get('category_name') or 'Без категории')
        card.description_label.setText(f"Описание: {(product.get('description') or 'Отсутствует')[:100]}...")
        card.manufacturer_label.setText(f"Производитель: {product.get('manufacturer_name', 'не указан')}")
        card.supplier_label.setText(f"Поставщики: {product.get('suppliers_list', 'не указаны')}")
        card.count_label.setText(f"В наличии: {product['stock']} шт.")
        card.price_label.setText(f"{product['price']:.2f} руб.")

        # Картинка
        card.image.setText("Нет фото")
        if img := product.get('image'):
            full_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), img)
            if os.path.exists(full_path) and (pix := QPixmap(full_path)) and not pix.isNull():
                card.image.setPixmap(pix.scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio))
                card.image.setText("")

        # Скрываем все кнопки
        card.btn_edit.hide()
        card.btn_delete.hide()
        card.btn_add_to_basket.hide()

        return card
    def exit_to_auth(self):
        """Выход из системы и возврат к окну авторизации"""
        from auth import AuthWindow
        self.auth_window = AuthWindow()
        self.auth_window.show()
        self.close()