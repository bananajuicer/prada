import pymysql
from pymysql.cursors import DictCursor


class Database:
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host='localhost',
                user='root',
                password='root',
                database='clothing_store',
                charset='utf8mb4',
                cursorclass=DictCursor,
                autocommit=True
            )
        except Exception as e:
            print(f"Ошибка подключения: {e}")

    def get_user(self, login, password):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                SELECT u.*, r.name as role_name 
                FROM users u 
                JOIN roles r ON u.role_id = r.id 
                WHERE u.login=%s AND u.password=%s
            """, (login, password))
            return cursor.fetchone()

    def get_all_clients(self):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                SELECT u.* FROM users u 
                JOIN roles r ON u.role_id = r.id 
                WHERE r.name = 'client'
                ORDER BY u.fio
            """)
            return cursor.fetchall()

    def get_categories(self):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT * FROM categories ORDER BY name")
            return cursor.fetchall()

    def get_manufacturers(self):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT * FROM manufacturers ORDER BY name")
            return cursor.fetchall()

    def get_suppliers(self):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT * FROM suppliers ORDER BY name")
            return cursor.fetchall()

    def get_products(self, search='', manufacturer_id=None, supplier_id=None):
        with self.connection.cursor() as cursor:
            sql = """
                SELECT p.*, c.name as category_name, m.name as manufacturer_name,
                       GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') as suppliers_list
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN manufacturers m ON p.manufacturer_id = m.id
                LEFT JOIN product_suppliers ps ON p.id = ps.product_id
                LEFT JOIN suppliers s ON ps.supplier_id = s.id
                WHERE (p.name LIKE %s OR p.description LIKE %s)
            """
            params = [f'%{search}%', f'%{search}%']

            if manufacturer_id:
                sql += " AND p.manufacturer_id = %s"
                params.append(manufacturer_id)

            if supplier_id:
                sql += " AND ps.supplier_id = %s"
                params.append(supplier_id)

            sql += " GROUP BY p.id ORDER BY p.name"
            cursor.execute(sql, params)
            return cursor.fetchall()

    def get_product_suppliers(self, product_id):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                SELECT supplier_id FROM product_suppliers WHERE product_id=%s
            """, (product_id,))
            return [row['supplier_id'] for row in cursor.fetchall()]

    def add_product(self, name, description, category_id, manufacturer_id, price, stock, image_path, suppliers):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                INSERT INTO products (name, description, category_id, manufacturer_id, price, stock, image)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (name, description, category_id, manufacturer_id, price, stock, image_path))
            product_id = cursor.lastrowid

            for sup_id in suppliers:
                cursor.execute(
                    "INSERT INTO product_suppliers (product_id, supplier_id) VALUES (%s, %s)",
                    (product_id, sup_id)
                )
            return product_id

    def update_product(self, product_id, name, description, category_id, manufacturer_id, price, stock, image_path,
                       suppliers):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                UPDATE products 
                SET name=%s, description=%s, category_id=%s, manufacturer_id=%s, 
                    price=%s, stock=%s, image=%s
                WHERE id=%s
            """, (name, description, category_id, manufacturer_id, price, stock, image_path, product_id))

            cursor.execute("DELETE FROM product_suppliers WHERE product_id=%s", (product_id,))
            for sup_id in suppliers:
                cursor.execute(
                    "INSERT INTO product_suppliers (product_id, supplier_id) VALUES (%s, %s)",
                    (product_id, sup_id)
                )

    def delete_product(self, product_id):
        with self.connection.cursor() as cursor:
            cursor.execute("DELETE FROM products WHERE id=%s", (product_id,))

    def get_order_statuses(self):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT * FROM order_statuses ORDER BY id")
            return cursor.fetchall()

    def get_orders(self, search='', date=None, client_id=None, status_id=None):
        with self.connection.cursor() as cursor:
            sql = """
                SELECT o.*, u.fio as client_name, os.name as status_name
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN order_statuses os ON o.status_id = os.id
                WHERE (CAST(o.id AS CHAR) LIKE %s OR u.fio LIKE %s)
            """
            params = [f'%{search}%', f'%{search}%']

            if date:
                sql += " AND o.order_date = %s"
                params.append(date)
            if client_id:
                sql += " AND o.user_id = %s"
                params.append(client_id)
            if status_id:
                sql += " AND o.status_id = %s"
                params.append(status_id)

            sql += " ORDER BY o.order_date DESC, o.id DESC"
            cursor.execute(sql, params)
            return cursor.fetchall()

    def update_order_status(self, order_id, status_id):
        with self.connection.cursor() as cursor:
            cursor.execute("UPDATE orders SET status_id=%s WHERE id=%s", (status_id, order_id))

    def get_client_orders(self, user_id):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                SELECT o.*, os.name as status_name
                FROM orders o
                JOIN order_statuses os ON o.status_id = os.id
                WHERE o.user_id = %s
                ORDER BY o.order_date DESC
            """, (user_id,))
            return cursor.fetchall()

    def create_order(self, user_id, address, payment_method, delivery_method, items):
        with self.connection.cursor() as cursor:
            total = sum(item['price'] * item['quantity'] for item in items)
            cursor.execute("""
                INSERT INTO orders (user_id, order_date, status_id, total_price, address, payment_method, delivery_method)
                VALUES (%s, CURDATE(), 1, %s, %s, %s, %s)
            """, (user_id, total, address, payment_method, delivery_method))
            order_id = cursor.lastrowid

            for item in items:
                cursor.execute("""
                    INSERT INTO order_items (order_id, product_id, quantity, price)
                    VALUES (%s, %s, %s, %s)
                """, (order_id, item['id'], item['quantity'], item['price']))
                cursor.execute("UPDATE products SET stock = stock - %s WHERE id = %s",
                               (item['quantity'], item['id']))
            return order_id

    def get_total_sales(self):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                SELECT SUM(total_price) as total 
                FROM orders 
                WHERE status_id = (SELECT id FROM order_statuses WHERE name = 'завершен')
            """)
            result = cursor.fetchone()
            return result['total'] if result['total'] else 0

    def get_orders_by_status(self):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                SELECT os.name as status, COUNT(o.id) as count, SUM(o.total_price) as sum
                FROM order_statuses os
                LEFT JOIN orders o ON os.id = o.status_id
                GROUP BY os.id, os.name
                ORDER BY os.id
            """)
            return cursor.fetchall()

    def get_popular_products(self, limit=5):
        with self.connection.cursor() as cursor:
            cursor.execute("""
                SELECT p.id, p.name, SUM(oi.quantity) as sold, SUM(oi.quantity * oi.price) as revenue
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                GROUP BY p.id, p.name
                ORDER BY sold DESC
                LIMIT %s
            """, (limit,))
            return cursor.fetchall()